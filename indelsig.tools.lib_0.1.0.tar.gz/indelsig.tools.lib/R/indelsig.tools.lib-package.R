## usethis namespace: start
#' @useDynLib indelsig.tools.lib, .registration = TRUE
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

